---
name: Architectural Noir
colors:
  surface: '#10131c'
  surface-dim: '#10131c'
  surface-bright: '#363943'
  surface-container-lowest: '#0b0e16'
  surface-container-low: '#181b24'
  surface-container: '#1c1f28'
  surface-container-high: '#272a33'
  surface-container-highest: '#32343e'
  on-surface: '#e0e2ee'
  on-surface-variant: '#c4c7c7'
  inverse-surface: '#e0e2ee'
  inverse-on-surface: '#2d303a'
  outline: '#8e9192'
  outline-variant: '#444748'
  surface-tint: '#c9c6c5'
  primary: '#c9c6c5'
  on-primary: '#313030'
  primary-container: '#050505'
  on-primary-container: '#797777'
  inverse-primary: '#5f5e5e'
  secondary: '#adc6ff'
  on-secondary: '#002e6a'
  secondary-container: '#0566d9'
  on-secondary-container: '#e6ecff'
  tertiary: '#ffb95f'
  on-tertiary: '#472a00'
  tertiary-container: '#0a0400'
  on-tertiary-container: '#a76a00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e5e2e1'
  primary-fixed-dim: '#c9c6c5'
  on-primary-fixed: '#1c1b1b'
  on-primary-fixed-variant: '#474646'
  secondary-fixed: '#d8e2ff'
  secondary-fixed-dim: '#adc6ff'
  on-secondary-fixed: '#001a42'
  on-secondary-fixed-variant: '#004395'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#10131c'
  on-background: '#e0e2ee'
  surface-variant: '#32343e'
  midnight: '#0A0C14'
  charcoal: '#121520'
  cyan-glow: '#06B6D4'
  gold-accent: '#D97706'
  text-primary: '#FFFFFF'
  text-secondary: '#D1D5DB'
  text-muted: '#9CA3AF'
  legacy-orange: '#FF6B35'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 72px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.04em
  headline-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Inter
    fontSize: 30px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.8'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-caps:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: '1.0'
    letterSpacing: 0.2em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  container-max: 1280px
  gutter: 32px
  margin-edge: 64px
  section-v-space: 160px
  unit: 8px
---

## Brand & Style

This design system embodies the persona of an ecosystem architect: strategic, profound, and technologically sophisticated. The aesthetic is **Dark Cinematic Editorial**, merging the precision of high-end tech interfaces with the gravitas of a luxury publication. 

The visual narrative focuses on "The Signal in the Noise"—utilizing deep, expansive voids (negative space) punctuated by sharp, intentional highlights. The style leverages **Glassmorphism** and **Minimalism**, where depth is not created through physical shadows, but through light refraction, layered transparencies, and subtle glow effects that suggest a world of interconnected data and high-level strategy.

## Colors

The palette is anchored in "Obsidian Tiers"—four levels of black and deep navy that provide structural depth without relying on traditional grays. 

- **Primary Backgrounds:** Use `#050505` for the base canvas. Use `Midnight` and `Charcoal` for sectioning and layered containers.
- **Accents:** Electric Blue (`#3B82F6`) and Cyan represent the "Technologist" side—logic and digital fluency. Amber and Gold represent the "Human" side—warmth, wisdom, and leadership.
- **Legacy Touch:** The `legacy-orange` from previous iterations is reserved strictly for micro-interactions or hidden data points to maintain continuity while evolving the brand.

## Typography

The system utilizes a single, highly-versatile typeface—**Inter**—pushed to its extremes to create editorial rhythm.

- **Headings:** Set with tight tracking and heavy weights to feel monumental and authoritative.
- **Body:** Set with generous leading (line height) to ensure readability against dark backgrounds, preventing "halation" (where white text appears to bleed into the black).
- **Section Eyebrows:** Use the `label-caps` style. These act as navigational anchors and should always be paired with a subtle accent-colored line or dot.

## Layout & Spacing

This design system employs a **Fixed-Fluid Hybrid Grid**. Content is centered within a 1280px container on desktop, but margins and padding expand fluidly to create a "vast" sensation.

- **Verticality:** Use massive vertical padding (`section-v-space`) between major content blocks to allow the "architectural" elements to breathe.
- **Grid:** A 12-column grid is standard. Asymmetric layouts are encouraged (e.g., content spanning columns 2-8) to mimic modern editorial magazines.
- **Mobile:** Margins shrink to 24px, and vertical spacing scales down to 80px.

## Elevation & Depth

Depth is conveyed through **Luminous Stratification** rather than physical drop shadows.

1.  **Base:** `#050505` (The infinite void).
2.  **Surface:** `#0A0C14` with a 1px border of `rgba(255, 255, 255, 0.05)`.
3.  **Floating (Glass):** Semi-transparent background blurs (20px+) using `Charcoal` at 60% opacity. 
4.  **Interaction:** Use a dual-layered glow. A 1px solid border of `Cyan` or `Amber` accompanied by a soft, 20px outer spread at 10% opacity of the same color.

**Network Traces:** Use thin (0.5px) lines at 10% opacity to connect related content blocks, simulating ecosystem mapping.

## Shapes

The shape language is **Precision-Engineered**. 

- **Corners:** Predominantly "Soft" (4px - 8px) to maintain a modern, professional look without feeling "bubbly."
- **Interactive Elements:** Buttons and tags may use slightly higher rounding (up to 12px) to distinguish them from structural containers.
- **Motifs:** Incorporate perfect circles for status indicators or "node" points in network traces, contrasting against the sharp lines of the grid.

## Components

### Buttons
- **Primary:** Pure White background with Deep Black text. Sharp corners. High contrast.
- **Secondary:** Ghost style. 1px border of `text-muted`, transitioning to `secondary-color` (Blue) on hover.
- **Tertiary:** Link style with the `label-caps` typography and an animated underline that expands from center.

### Cards
- **The "Ecosystem Card":** Background of `charcoal`. 1px subtle border. On hover, a soft `cyan-glow` appears from the top-left corner internally, and the border color brightens.

### Input Fields
- Darkest background (`#050505`). Bottom-border only (1px). Label moves above the line on focus, changing to `Cyan`.

### Timeline/Workflow Traces
- A custom component using a vertical or horizontal line (0.5px). Active steps are marked with a `gold-accent` glow, while inactive steps are simple `text-muted` dots.

### Navigation
- Top-aligned, fixed-position glassmorphism bar. High backdrop blur. Minimalist logo placement.