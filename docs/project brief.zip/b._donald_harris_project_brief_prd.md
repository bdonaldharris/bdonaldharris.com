# Project Brief & PRD: B. Donald Harris Personal Brand Ecosystem

## 1. Project Overview
**Brand Identity:** B. Donald Harris — Founder, Builder, Technologist, Ecosystem Architect.
**Core Objective:** To establish a premium, editorial digital home that unifies several distinct but connected ventures (NotableBIT, HindSite, BitVoices Network) under a single authoritative personal brand.
**Target Audience:** Conference organizers, Black tech founders, corporate partners, technology investors, and the BitVoices community.

## 2. Strategic Positioning
B. Donald Harris sits at the intersection of AI engineering, faith-rooted leadership, and Black tech ownership. The site must communicate:
- **Authority:** Decades of engineering and leadership experience.
- **Unity:** NotableBIT, HindSite, and BitVoices are aligned vehicles, not random projects.
- **Humanity:** Integrating a late autism diagnosis and faith-rooted purpose with dignity and clarity.
- **Innovation:** A forward-leaning focus on AI, comprehension debt, and workflow intelligence.

## 3. Visual & Design System ("Architectural Noir")
- **Atmosphere:** Dark, cinematic, editorial, and dignified.
- **Color Palette:**
  - *Primary:* Deep Midnight Navy (#10131c), charcoal slates.
  - *Accents:* Cyan glow, warm amber, and soft gold (used for "signal" vs. "noise").
- **Typography:** Bold, premium sans-serif headings; high-readability body text; tracked uppercase labels for hierarchy.
- **Motifs:** Subtle grid lines, workflow traces, network nodes, and abstract signal textures.

## 4. Information Architecture (Screen List)
1. **Home:** High-level narrative, ecosystem snapshot, and primary CTAs.
2. **About:** Deep-dive origin story, career timeline, and belief statements.
3. **Speaking:** Topic cards, formats, and booking conversion paths.
4. **Projects:** The "Ecosystem Map" showing how NotableBIT and HindSite connect.
5. **Ideas:** A premium editorial home for essays and thought leadership.
6. **Media:** Podcast archives, speaking clips, and a "Press Kit Lite."
7. **Contact:** Intentional, inquiry-based communication paths.

## 5. Functional Requirements
- **Responsive Design:** Premium experience across desktop and mobile.
- **Performance:** Optimized for high-resolution editorial imagery and smooth transitions.
- **Accessibility:** WCAG 2.1 compliance with high contrast ratios and keyboard-friendly navigation.
- **Content Strategy:** Ambitious but honest (e.g., "Building HindSite" vs. "Market Leader").

## 6. Key Components
- **TopNavBar:** Fixed, glassmorphism (surface/60 blur), uppercase labels.
- **Footer:** Ecosystem-style grid mapping the "NotableBIT" family.
- **Insight Cards:** Editorial-style blocks for core beliefs.
- **Ecosystem Map:** Interactive or visual representation of project relationships.
- **Speaking Topic Cards:** Standardized units for conference outreach.
